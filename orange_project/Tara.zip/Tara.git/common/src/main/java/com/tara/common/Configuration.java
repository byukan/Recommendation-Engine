package com.tara.common;

public class Configuration {

	public static final String MYSQLJDBCDRIVER = "com.mysql.jdbc.Driver";
	public static final String MYSQLDBHOST = "localhost";
	public static final String MYSQLDBPORT = "3306";
	public static final String MYSQLDBURL = "jdbc:mysql://" + MYSQLDBHOST + ":"
			+ MYSQLDBPORT + "/courserecommender";
	
	
	
	public static final String MYSQLDBUSERNAME = "root";
	public static final String MYSQLDBPASSWORD = "";
	public static final String PIOAPPURL = "";
	public static final String PIOAPPACCESSKEY = "";
	
	

}
