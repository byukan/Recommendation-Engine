package com.tara.common;

public class Constants {
	public static String INCLUDEALL = "ALL";

	public static String INCLUDETAKEN = "TAKEN";

	public static String INCLUDENOTTAKEN = "NOT-TAKEN";
	public static String REQUEST_TYPE_REST = "rest";
	public static String REQUEST_TYPE_EMAIL = "email";

}
