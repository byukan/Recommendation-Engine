package com.tara.common;

public class Recommendation {
	public Recommendation(String userId, int count) {
		super();
		this.userId = userId;
		this.count = count;
	}
	public String userId;
	public int count;
	
	

}
