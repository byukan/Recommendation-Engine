package com.tara.common;


public interface FuzzyMatcher {

	public Integer fuzzyScore(String term, String query) ;
}
