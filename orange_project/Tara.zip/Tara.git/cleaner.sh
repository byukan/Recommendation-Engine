rm courses
rm step
rm uip
rm sg
rm ur
rm gm
rm proj
rm amazon