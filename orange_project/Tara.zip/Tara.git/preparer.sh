rm amazon
rm uip
rm sg
rm ur
rm gm
rm proj

cp /immuta/Tara\ Accessible\ Amazon\ Report/* amazon
cp /immuta/Tara\ Accessible\ Users\ Info\ Plazza/* uip
cp /immuta/Tara\ Accessible\ Social\ Group/* sg
cp /immuta/Tara\ Accessible\ User\ Relation/* ur
cp /immuta/Tara\ Accessible\ Group\ Member/* gm
cp /immuta/Tara\ Accessible\ Project/* proj
