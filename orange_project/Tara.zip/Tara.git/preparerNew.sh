rm courses
rm step
rm uip
rm sg
rm ur
rm gm
rm proj
rm trainCatalog
cp /immuta/Combined\ Course\ Catalog/* courses
cp /immuta/Tara\ Accessible\ STEP\ Report/* step
cp /immuta/Tara\ Accessible\ Users\ Info\ Plazza/* uip
cp /immuta/Tara\ Accessible\ Social\ Group/* sg
cp /immuta/Tara\ Accessible\ User\ Relation/* ur
cp /immuta/Tara\ Accessible\ Group\ Member/* gm
cp /immuta/Tara\ Accessible\ Project/* proj
cp /immuta/Training\ Update\ Catalog/* trainCatalog

