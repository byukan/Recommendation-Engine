curl -H "Content-Type:Application/JSON" -d '{"employeeID":"'$1'","count":'$2'}' -X GET http://192.168.161.79:5000/recommendations/email
